#include <stdio.h>

int main () {
    char batata[50];
    scanf("%s",&batata);
    batata[3]='i';
    printf("%s",batata);
}